package com.demo.coffee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoN21CoffeeSaleApplicationTests {

	@Test
	void contextLoads() {
	}

}
