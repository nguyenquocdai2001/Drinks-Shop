package com.demo.coffee;
import org.springframework.core.SpringVersion;

public class VersionCheckerr {
	  public static void main(String [] args)
	  {
	      System.out.println("version: " + SpringVersion.getVersion());
	  }
}
